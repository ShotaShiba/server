const replaceSpan = '　 島 貴彦<br>2001年3月5日 / 平成13年3月5日';

const waitFor = (selector, callback) => {
    const el = document.querySelector(selector);
    if (el) return callback(el);
    setTimeout(() => waitFor(selector, callback), 500);
};

// 要素が見つかるまで待機
const replace = () => {
    const container = document.querySelector('.ticket_info_container')
    const span = container.querySelector('span[style*="font-size: 90%"]');
    span.innerHTML = replaceSpan;

};
replace();s